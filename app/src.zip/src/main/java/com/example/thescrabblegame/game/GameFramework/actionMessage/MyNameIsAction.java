package com.example.thescrabblegame.game.GameFramework.actionMessage;

import com.example.thescrabblegame.game.GameFramework.players.GamePlayer;

/**
 * An action by which the player tells the game its name
 * (typically the human's name, if it's a GameHumanPlayer).
 *
 * @author Steven R. Vegdahl
 * @version July 2013
 */
public class MyNameIsAction extends GameAction {
    //Tag for logging
    private static final String TAG = "MyNameIsAction";
    // to satisfy the Serializable interface
    private static final long serialVersionUID = -4574617895412648866L;

    // the player's name
    private String name;

    /** constructor
     *
     * @param p
     * 		the player who sent the action
     * @param name
     * 		the player's name
     */
    public MyNameIsAction(GamePlayer p, String name) {
        super(p); // invoke superclass constructor
        this.name = name; // set the name
    }

    /**
     * getter-method for the name
     *
     * @return
     * 		the player's name
     */
    public String getName() {
        return name;
    }

}